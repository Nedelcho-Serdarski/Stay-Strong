package bg.softuni.staystrong.web;

import bg.softuni.staystrong.Supplements.Model.Supplements;
import bg.softuni.staystrong.Supplements.SupplementsRepository.SupplementsRepository;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/supplements")
public class SupplementsController {
    private final SupplementsRepository supplementsRepository;
    private final UserRepository userRepository;

    public SupplementsController(SupplementsRepository supplementsRepository, UserRepository userRepository) {
        this.supplementsRepository = supplementsRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public String showSupplements(Model model, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);

        List<Supplements> supplementsList = (user != null) ?
                supplementsRepository.findByUser(user) :
                supplementsRepository.findAll();

        model.addAttribute("supplements", supplementsList);
        return "supplements"; // Трябва да имаш файл supplements.html в resources/templates
    }
    //✔ @GetMapping("/supplements") връща supplements.html
    //✔ Взимаме текущия потребител чрез Principal principal
    //✔ Зареждаме само неговите добавки, ако е влязъл, или всички добавки, ако не е



    @PostMapping
    public String addSupplement(@RequestParam String name, @RequestParam String dailyDose, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);
        if (user == null) {
            return "redirect:/supplements"; // Ако няма логнат потребител, не добавя нищо
        }

        Supplements supplement = Supplements.builder()
                .name(name)
                .dailyDose(dailyDose)
                .user(user)
                .build();

        supplementsRepository.save(supplement);
        return "redirect:/supplements"; // Презареждаме страницата
    }
   // Взима въведените в формата данни
    // Взима логнатия потребител
    // Запазва новата добавка в базата данни
    // Презарежда страницата, за да покажем новата добавка
}
