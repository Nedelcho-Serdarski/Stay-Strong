package bg.softuni.staystrong.Exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
        // Когато няма намерен потребител, липсващ обект в базата и т.н.
    }
}
