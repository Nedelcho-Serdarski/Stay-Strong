package bg.softuni.staystrong.web.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MacronutrientDTO {

        private double proteins;
        private double fats;
        private double carbs;

        public MacronutrientDTO(double proteins, double fats, double carbs) {
            this.proteins = proteins;
            this.fats = fats;
            this.carbs = carbs;
        }

        public double getProteins() {
            return proteins;
        }

        public double getFats() {
            return fats;
        }

        public double getCarbs() {
            return carbs;
        }
    }


