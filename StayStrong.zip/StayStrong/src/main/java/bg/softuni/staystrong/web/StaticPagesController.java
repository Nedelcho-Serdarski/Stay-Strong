package bg.softuni.staystrong.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StaticPagesController {


        @GetMapping("/healthy-lifestyle")
        public String healthyLifestyle() {
            return "healthy-lifestyle"; // Това трябва да съответства на името на Thymeleaf темплейта
        }

        @GetMapping("/antiaging")
        public String antiAging() {
            return "antiaging";
        }

        @GetMapping("/contact")
        public String contact() {
            return "contact";
        }
    }


