package bg.softuni.staystrong.Diet.Model;

import bg.softuni.staystrong.User.Model.User;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;
@Entity
@Data
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class Diet {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;


    private String typeOfDiet;

    @ManyToOne
    private User user;


}
