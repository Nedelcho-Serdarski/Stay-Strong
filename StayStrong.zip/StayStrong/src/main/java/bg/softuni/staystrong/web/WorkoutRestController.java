package bg.softuni.staystrong.web;

import bg.softuni.staystrong.WorkOut.Model.Workout;
import bg.softuni.staystrong.WorkOut.WorkoutService.WorkoutService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workouts")
public class WorkoutRestController {
    private final WorkoutService workoutService;

    public WorkoutRestController(WorkoutService workoutService) {
        this.workoutService = workoutService;
    }

    // GET all workouts
    @GetMapping
    public ResponseEntity<List<Workout>> getAllWorkouts() {
        return ResponseEntity.ok(workoutService.getAllWorkouts());
    }

    // POST a new workout
    @PostMapping
    public ResponseEntity<Workout> createWorkout(@RequestBody Workout workout) {
        Workout savedWorkout = workoutService.createWorkout(workout);
        return ResponseEntity.ok(savedWorkout);
    }
}
