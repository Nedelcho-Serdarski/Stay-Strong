package bg.softuni.staystrong.web;

import bg.softuni.staystrong.web.DTO.MacronutrientDTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/goals")
public class GoalController {


    @GetMapping("/cutting")
    public String cuttingPage(Model model, @RequestParam double tdee, @RequestParam double weight) {
        double calories = tdee * 0.9;
        MacronutrientDTO macros = calculateMacros(calories, weight);

        model.addAttribute("goal", "Изчистване на мазнини");
        model.addAttribute("calories", (int) calories);
        model.addAttribute("macros", macros);

        return "cutting";
    }

    @GetMapping("/bulking")
    public String bulkingPage(Model model, @RequestParam double tdee, @RequestParam double weight) {
        double calories = tdee * 1.1;
        MacronutrientDTO macros = calculateMacros(calories, weight);

        model.addAttribute("goal", "Покачване на мускулна маса");
        model.addAttribute("calories", (int) calories);
        model.addAttribute("macros", macros);

        return "bulking";
    }

    private MacronutrientDTO calculateMacros(double calories, double weightKg) {
        double proteinGrams = weightKg * 2.0;
        double fatGrams = weightKg * 1.0;
        double proteinCalories = proteinGrams * 4;
        double fatCalories = fatGrams * 9;
        double carbCalories = calories - proteinCalories - fatCalories;
        double carbsGrams = carbCalories / 4;

        return new MacronutrientDTO(proteinGrams, fatGrams, carbsGrams);
    }
}




