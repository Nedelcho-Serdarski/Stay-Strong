package bg.softuni.staystrong.web;

import bg.softuni.staystrong.Diet.DietService.DietRepository;
import bg.softuni.staystrong.Diet.Model.Diet;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/diet")
public class DietController {

    private final DietRepository dietRepository;
    private final UserRepository userRepository;

    public DietController(DietRepository dietRepository, UserRepository userRepository) {
        this.dietRepository = dietRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public String showDiet(Model model, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);

        List<Diet> dietList = (user != null) ?
                dietRepository.findByUser(user) :
                dietRepository.findAll();

        model.addAttribute("diets", dietList);
        return "diet";
    }

    @PostMapping
    public String addDiet(@RequestParam String typeOfDiet, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);
        if (user == null) {
            return "redirect:/diet";
        }

        Diet diet = Diet.builder()
                .typeOfDiet(typeOfDiet)
                .user(user)
                .build();

        dietRepository.save(diet);
        return "redirect:/diet";
    }
    // GET /diet – Показва всички диети
    // POST /diet – Добавя нова диета
    // Взима логнатия потребител и записва диетата към него
}
