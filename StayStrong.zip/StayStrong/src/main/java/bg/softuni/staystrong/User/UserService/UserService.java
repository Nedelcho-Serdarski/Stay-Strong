package bg.softuni.staystrong.User.UserService;

import bg.softuni.staystrong.Config.security.AuthenticationMetaData;
import bg.softuni.staystrong.Exception.DomainException;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.Model.UserRole;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import bg.softuni.staystrong.web.DTO.RegisterRequest;
import bg.softuni.staystrong.web.DTO.UserEditRequest;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
@Slf4j
@Service
public class UserService implements UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }




        @Transactional
        public User register(RegisterRequest registerRequest) {

            Optional<User> optionUser = userRepository.findByUsername(registerRequest.getUsername());
            if (optionUser.isPresent()) {
                throw new RuntimeException("Username  already exist.");
            }

            User user = userRepository.save(initializeUser(registerRequest));
            return user;
        }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

       User user = userRepository.findByUsername(username).orElseThrow(() -> new DomainException("User with this username not found."));
        return new AuthenticationMetaData(user.getId(),username,user.getPassword(),user.getRole(),user.isActive());
    }

    public User getById(UUID id) {

        return userRepository.findById(id).orElseThrow(() -> new DomainException("User with id [%s] does not exist.".formatted(id)));
    }
            private User initializeUser(RegisterRequest registerRequest) {

                return User.builder()
                        .username(registerRequest.getUsername())
                        .password(passwordEncoder.encode(registerRequest.getPassword()))
                        .role(UserRole.USER)
                        .isActive(true)
                        .build();
            }

    @CacheEvict(value = "users", allEntries = true)
    public void editUserDetails(UUID userId, UserEditRequest userEditRequest) {

        User user = getById(userId);

        user.setFirstName(userEditRequest.getFirstName());
        user.setLastName(userEditRequest.getLastName());
        user.setEmail(userEditRequest.getEmail());
        userRepository.save(user);
    }

    public User findByUsername(String name) {

        return userRepository.findByUsername(name).orElseThrow(() -> new DomainException("User with this username not found."));
    }
    // В началото се изпълнява веднъж този метод и резултата се пази в кеш
    // Всяко следващо извикване на този метод ще се чете резултата от кеша и няма да се извиква четенето от базата
    @Cacheable("users")
    public List<User> getAllUsers() {

        return userRepository.findAll();
    }
    @Transactional
    public void makeUserAdmin(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new DomainException("User not found."));

        user.setRole(UserRole.ADMIN);
        userRepository.save(user);
    }// така можеш да извикаш метода да смениш ролята userService.makeUserAdmin(userId)


}
