package bg.softuni.staystrong.web.mapper;

import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.web.DTO.UserEditRequest;
import lombok.experimental.UtilityClass;

@UtilityClass
public class DtoMapper {

    public static UserEditRequest mapUserToUserEditRequest(User user) {

        return UserEditRequest.builder()
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .email(user.getEmail())
                .build();
    }
}
