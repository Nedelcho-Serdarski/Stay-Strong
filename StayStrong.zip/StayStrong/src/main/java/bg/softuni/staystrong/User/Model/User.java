package bg.softuni.staystrong.User.Model;

import bg.softuni.staystrong.Diet.Model.Diet;
import bg.softuni.staystrong.Progress.Model.Progress;
import bg.softuni.staystrong.Story.Model.Story;
import bg.softuni.staystrong.Supplements.Model.Supplements;
import bg.softuni.staystrong.WorkOut.Model.Workout;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Data
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String username;

    private String firstName;

    private String lastName;



    @Column(nullable = false, unique = true)
    private String password;

    @Column( unique = true)
    private String email;

    private boolean isActive;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user")
    private List<Story> stories = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user")
    private List<Diet> diets = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user")
    private List<Supplements> supplements = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user")
    private List<Workout> workouts = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER,mappedBy = "user")
    private List<Progress> progresses = new ArrayList<>();


}

