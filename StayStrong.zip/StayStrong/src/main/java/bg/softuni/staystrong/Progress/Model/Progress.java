package bg.softuni.staystrong.Progress.Model;

import bg.softuni.staystrong.User.Model.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Progress {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)

    private UUID id;
    @Column(nullable = false)
    private int weight;

    @Column(nullable = false)
    private int bodyFat;

    @ManyToOne
    private User user;

}
