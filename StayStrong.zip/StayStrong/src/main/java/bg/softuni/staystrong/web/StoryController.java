package bg.softuni.staystrong.web;

import bg.softuni.staystrong.Config.security.AuthenticationMetaData;
import bg.softuni.staystrong.Story.StoryService.StoryService;
import bg.softuni.staystrong.User.UserService.UserService;
import bg.softuni.staystrong.web.DTO.StoryDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/stories")
@PreAuthorize("hasRole('USER')")

public class StoryController {
    private final StoryService storyService;
    private final UserService userService;

    @Autowired
    public StoryController(StoryService storyService, UserService userService) {
        this.storyService = storyService;
        this.userService = userService;
    }

    @GetMapping
    public String getAllStories(Model model, @AuthenticationPrincipal AuthenticationMetaData authUser) {
        List<StoryDTO> stories = storyService.getAllStories();
        model.addAttribute("stories", stories);

        if (authUser != null) {

            model.addAttribute("currentUser", authUser.getUsername());
        }
        return "story";
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()") // Ensuring only logged-in users can create stories
    public String createStory(@ModelAttribute StoryDTO storyDTO, @AuthenticationPrincipal AuthenticationMetaData authUser) {
        if (authUser == null) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof AuthenticationMetaData) {
                authUser = (AuthenticationMetaData) authentication.getPrincipal();
            }
        }

        if (authUser != null) {
            storyDTO.setUsername(authUser.getUsername());
            storyDTO.setDate(LocalDate.now());
            storyService.createStory(storyDTO);
        }
        return "redirect:/stories";
    }

}