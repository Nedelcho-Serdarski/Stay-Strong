package bg.softuni.staystrong.web;

import bg.softuni.staystrong.User.UserService.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    private final UserService userService;

    public HomeController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/story")
    public String showStoryPage() {
        return "story";
    }

    @GetMapping("/editprofile")
    public String editProfilePage() {
        return "profile-menu";
    }



}
