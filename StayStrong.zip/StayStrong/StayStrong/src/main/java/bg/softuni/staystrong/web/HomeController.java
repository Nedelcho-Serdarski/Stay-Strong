package bg.softuni.staystrong.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/story")
    public String showStoryPage() {
        return "story";
    }

    @GetMapping("/editprofile")
    public String editProfilePage() {
        return "profile-menu";
    }

}
