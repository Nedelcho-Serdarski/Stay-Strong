package bg.softuni.staystrong.WorkOut.Model;

import bg.softuni.staystrong.User.Model.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Data
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Workout {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String typeOfWorkout;

    @Column(nullable = false)
    private LocalDate date;

    @ManyToOne
    private User user;
}
