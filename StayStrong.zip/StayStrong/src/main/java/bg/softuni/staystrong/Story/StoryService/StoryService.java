package bg.softuni.staystrong.Story.StoryService;

import bg.softuni.staystrong.Story.Model.Story;
import bg.softuni.staystrong.Story.StoryRepository.StoryRepository;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.UserService.UserService;
import bg.softuni.staystrong.web.DTO.StoryDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class StoryService {
    private final StoryRepository storyRepository;
    private final UserService userService;

    @Autowired
    public StoryService(StoryRepository storyRepository, UserService userService) {
        this.storyRepository = storyRepository;
        this.userService = userService;
    }


    public List<StoryDTO> getAllStories() {
        return storyRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public void createStory(StoryDTO storyDTO) {
        User user = userService.findByUsername(storyDTO.getUsername());
        Story story = Story.builder()
                .title(storyDTO.getTitle())
                .content(storyDTO.getContent())
                .date(storyDTO.getDate() != null ? storyDTO.getDate() : LocalDate.now())
                .user(user)
                .build();
        storyRepository.save(story);
    }

    private StoryDTO convertToDTO(Story story) {
        return new StoryDTO(
                story.getId(),
                story.getTitle(),
                story.getContent(),
                story.getDate(),
                story.getUser().getUsername()
        );
    }
}
