package bg.softuni.staystrong.WorkOut.WorkoutRepository;

import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.WorkOut.Model.Workout;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface WorkoutRepository extends JpaRepository<Workout, UUID> {

    List<Workout> findByUser(User user);
    //Добавя метод за намиране на тренировки на конкретен потребител

}
