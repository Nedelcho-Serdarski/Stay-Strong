package bg.softuni.staystrong.User;

import bg.softuni.staystrong.Exception.DomainException;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.Model.UserRole;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import bg.softuni.staystrong.User.UserService.UserService;
import bg.softuni.staystrong.web.DTO.RegisterRequest;
import bg.softuni.staystrong.web.DTO.UserEditRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.UUID;

import static org.hamcrest.Matchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        user = User.builder()
                .id(UUID.randomUUID())
                .username("testuser")
                .password("encodedPassword")
                .role(UserRole.USER)
                .isActive(true)
                .build();
    }




    @Test
    void register_ShouldThrowException_WhenUsernameAlreadyExists() {
        RegisterRequest registerRequest = new RegisterRequest("testuser", "password");
        when(userRepository.findByUsername(registerRequest.getUsername())).thenReturn(Optional.of(user));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> userService.register(registerRequest));
        assertEquals("Username  already exist.", exception.getMessage());
    }

    @Test
    void getById_ShouldReturnUser_WhenUserExists() {
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        User foundUser = userService.getById(user.getId());

        assertNotNull(foundUser);
        assertEquals(user.getId(), foundUser.getId());
    }

    @Test
    void getById_ShouldThrowException_WhenUserNotFound() {
        UUID userId = UUID.randomUUID();
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        DomainException exception = assertThrows(DomainException.class, () -> userService.getById(userId));
        assertEquals("User with id [%s] does not exist.".formatted(userId), exception.getMessage());
    }

    @Test
    void makeUserAdmin_ShouldUpdateUserRoleToAdmin() {
        UUID userId = UUID.randomUUID();
        User userToPromote = User.builder()
                .id(userId)
                .username("testuser")
                .password("encodedPassword")
                .role(UserRole.USER)
                .isActive(true)
                .build();

        when(userRepository.findById(userId)).thenReturn(Optional.of(userToPromote));

        userService.makeUserAdmin(userId);

        assertEquals(UserRole.ADMIN, userToPromote.getRole());
        verify(userRepository, times(1)).save(userToPromote);
    }
}
