package bg.softuni.staystrong.User.Model;

public enum UserRole {
    USER, ADMIN;
}
