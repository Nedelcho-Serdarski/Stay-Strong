package bg.softuni.staystrong.Diet.DietService;

import bg.softuni.staystrong.Diet.Model.Diet;
import bg.softuni.staystrong.User.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface DietRepository extends JpaRepository<Diet, UUID> {

    List<Diet> findByUser(User user);
  //  Добавя метод за намиране на диети на конкретен потребител
}
