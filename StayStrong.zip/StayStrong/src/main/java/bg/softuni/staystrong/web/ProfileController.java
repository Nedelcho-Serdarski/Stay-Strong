package bg.softuni.staystrong.web;

import bg.softuni.staystrong.Exception.ResourceNotFoundException;
import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import bg.softuni.staystrong.User.UserService.UserService;
import bg.softuni.staystrong.web.DTO.UserEditRequest;
import bg.softuni.staystrong.web.mapper.DtoMapper;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.UUID;

@Controller
public class ProfileController {
    private final UserRepository userRepository;

    public ProfileController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/profile-menu")
    public String showEditProfile(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails != null) {
            User user = userRepository.findByUsername(userDetails.getUsername())
                    .orElseThrow(() -> new ResourceNotFoundException("User Not Found!"));
            model.addAttribute("user", user);
        }
        return "profile-edit";
    }

    @PostMapping("/profile-menu")
    public String updateProfile(@AuthenticationPrincipal UserDetails userDetails,
                                @RequestParam String email,
                                @RequestParam String username) {
        if (userDetails != null) {
            User user = userRepository.findByUsername(userDetails.getUsername()).orElse(null);
            if (user != null) {
                user.setEmail(email);
                user.setUsername(username);
                userRepository.save(user);
            }
        }
        return "redirect:/home";
    }
    // GET /profile-menu → Зарежда текущия потребител и показва формата за редакция
    // POST /profile-menu → Обновява данните на потребителя и записва в базата
}





