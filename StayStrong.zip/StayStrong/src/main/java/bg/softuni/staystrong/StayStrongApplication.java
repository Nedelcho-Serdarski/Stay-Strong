package bg.softuni.staystrong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StayStrongApplication {

    public static void main(String[] args) {
        SpringApplication.run(StayStrongApplication.class, args);
    }

}
