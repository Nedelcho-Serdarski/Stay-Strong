package bg.softuni.staystrong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StayStrongApplicationTests {

    @Test
    void contextLoads() {
    }

}
