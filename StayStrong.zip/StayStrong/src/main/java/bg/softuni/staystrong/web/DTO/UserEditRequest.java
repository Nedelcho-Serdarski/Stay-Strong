package bg.softuni.staystrong.web.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;
import org.hibernate.validator.constraints.URL;
@Data
@Builder

public class UserEditRequest {

    @Size(max = 20, message = "First name can't have more than 20 symbols")
    private String firstName;

    @Size(max = 20, message = "Last name can't have more than 20 symbols")
    private String lastName;

    private int age;

    private String goals;
    @Email(message = "Requires correct email format")
    private String email;

    public UserEditRequest(String firstName, String lastName, int age, String goals, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.goals = goals;
        this.email = email;
    }

    public UserEditRequest(String newFirstName, String newLastName, int age) {
    }
}

