package bg.softuni.staystrong.Calories.Service;

import bg.softuni.staystrong.web.DTO.caloriesRequest;
import org.springframework.stereotype.Service;

@Service
public class CaloriesService {
    public int calculateCalories(caloriesRequest form) {
        double bmr;

        if ("male".equalsIgnoreCase(form.getGender())) {
            bmr = 10 * form.getWeight() + 6.25 * form.getHeight() - 5 * form.getAge() + 5;
        } else {
            bmr = 10 * form.getWeight() + 6.25 * form.getHeight() - 5 * form.getAge() - 161;
        }

        return (int) Math.round(bmr * form.getActivityLevel());
    }
}
