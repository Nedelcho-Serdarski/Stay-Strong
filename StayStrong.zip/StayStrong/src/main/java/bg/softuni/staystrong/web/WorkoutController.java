package bg.softuni.staystrong.web;

import bg.softuni.staystrong.User.Model.User;
import bg.softuni.staystrong.User.UserRepository.UserRepository;
import bg.softuni.staystrong.WorkOut.Model.Workout;
import bg.softuni.staystrong.WorkOut.WorkoutRepository.WorkoutRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/workout")
public class WorkoutController {

    private final WorkoutRepository workoutRepository;
    private final UserRepository userRepository;

    public WorkoutController(WorkoutRepository workoutRepository, UserRepository userRepository) {
        this.workoutRepository = workoutRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public String showWorkouts(Model model, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);

        List<Workout> workouts = (user != null) ?
                workoutRepository.findByUser(user) :
                workoutRepository.findAll();

        model.addAttribute("workouts", workouts);
        return "workout";
    }

    @PostMapping
    public String addWorkout(@RequestParam String typeOfWorkout, @RequestParam String date, Principal principal) {
        User user = userRepository.findByUsername(principal.getName()).orElse(null);
        if (user == null) {
            return "redirect:/workout";
        }

        Workout workout = Workout.builder()
                .typeOfWorkout(typeOfWorkout)
                .date(LocalDate.parse(date))
                .user(user)
                .build();

        workoutRepository.save(workout);
        return "redirect:/workout";
    }

    //GET /workout – Показва всички тренировки
    // POST /workout – Добавя нова тренировка
    // Изисква потребителят да е логнат


}
