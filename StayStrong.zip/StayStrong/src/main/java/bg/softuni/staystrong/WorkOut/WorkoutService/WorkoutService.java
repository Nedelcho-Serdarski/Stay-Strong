package bg.softuni.staystrong.WorkOut.WorkoutService;

import bg.softuni.staystrong.WorkOut.Model.Workout;
import bg.softuni.staystrong.WorkOut.WorkoutRepository.WorkoutRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkoutService {
    private final WorkoutRepository workoutRepository;

    public WorkoutService(WorkoutRepository workoutRepository) {
        this.workoutRepository = workoutRepository;
    }

    public List<Workout> getAllWorkouts() {
        return workoutRepository.findAll();
    }

    public Workout createWorkout(Workout workout) {
        return workoutRepository.save(workout);
    }
}
