package bg.softuni.staystrong.web.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StoryDTO {
    private UUID id;
    @NotBlank(message = "Title cannot be empty!")
    @Size(min = 5, max = 25,message = "Title length must be between 5 and 25 characters!")
    private String title;
    private String content;
    @NotNull(message = "must not be null.")
    private LocalDate date;

    private String username;







}
