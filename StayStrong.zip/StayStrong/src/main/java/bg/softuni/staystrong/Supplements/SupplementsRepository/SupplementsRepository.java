package bg.softuni.staystrong.Supplements.SupplementsRepository;

import bg.softuni.staystrong.Supplements.Model.Supplements;
import bg.softuni.staystrong.User.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SupplementsRepository extends JpaRepository<Supplements, UUID> {

    List<Supplements> findByUser(User user);
}
